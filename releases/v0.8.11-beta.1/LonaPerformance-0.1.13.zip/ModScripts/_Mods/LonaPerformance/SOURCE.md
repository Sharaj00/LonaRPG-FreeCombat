# Source

Authored numeric DLL, built from source/geometry.c with MSVC x86. No game or RGSS binaries are included. GC batching is experimental and disabled by default.
